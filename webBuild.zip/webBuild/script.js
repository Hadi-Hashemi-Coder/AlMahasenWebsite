
//Navigation bar

var navbar = document.getElementsByClassName("navbar")[0];
var navbarStart = navbar.offsetTop;

window.onscroll = function() {
    if (window.innerWidth > 600) {navbarSwitch();}
}

function navbarSwitch() {
  if (window.pageYOffset > navbarStart) {
    navbar.style.backgroundColor = "rgb(234, 81, 162)";
  } else {
    navbar.style.backgroundColor = "transparent";
  }
}

const toggleButton = document.getElementsByClassName("toggle-button")[0]
const navbarLinks = document.getElementsByClassName("navbar-links")[0]

toggleButton.addEventListener("click",() => {
    navbarLinks.classList.toggle('active')
})

//Ad slideshow
const myslide = document.querySelectorAll('.myslider');
const dot = document.querySelectorAll('.dot');

let counter = 1;
slidefun(counter);

let timer = setInterval(autoslide, 8000);
function autoslide() {
    counter += 1;
    slidefun(counter);
}
function plusSlides(n) {
    counter += n;
    slidefun(counter);
    resetTimer();
}
function currentSlide(n) {
    counter = n;
    slidefun(counter);
    resetTimer();
}
function resetTimer(){
    clearInterval(timer);
    timer = setInterval(autoslide, 8000);
}

function slidefun(n) {
    let i;
    for(i = 0;i<myslide.length;i++){
        myslide[i].style.display = "none";
    }
    for(i = 0;i<dot.length;i++){
        dot[i].classList.remove('active');
    }
    if(n > myslide.length){
        counter = 1;
    }
    if(n < 1){
        counter = myslide.length;
    }
    myslide[counter - 1].style.display = "block";
    dot[counter - 1].classList += " active";
}

// Modals Popups

const modal = document.querySelectorAll('#my-modal');
const closeBtn = document.querySelectorAll('.close');

closeBtn[0].addEventListener('click', closeModal);
closeBtn[1].addEventListener('click', closeModal);
closeBtn[2].addEventListener('click', closeModal);
closeBtn[3].addEventListener('click', closeModal);
closeBtn[4].addEventListener('click', closeModal);
closeBtn[5].addEventListener('click', closeModal);
closeBtn[6].addEventListener('click', closeModal);
closeBtn[7].addEventListener('click', closeModal);
closeBtn[8].addEventListener('click', closeModal);
closeBtn[9].addEventListener('click', closeModal);
closeBtn[10].addEventListener('click', closeModal);
closeBtn[11].addEventListener('click', closeModal);
closeBtn[12].addEventListener('click', closeModal);
closeBtn[13].addEventListener('click', closeModal);
closeBtn[14].addEventListener('click', closeModal);
window.addEventListener('click', outsideClick);

function closeModal() {
  modal1.style.display = 'none';
  modal2.style.display = 'none';
  modal3.style.display = 'none';
  modal4.style.display = 'none';
  modal5.style.display = 'none';
  modal6.style.display = 'none';
  modal7.style.display = 'none';
  modal8.style.display = 'none';
  modal9.style.display = 'none';
  modal10.style.display = 'none';
  modal11.style.display = 'none';
  modal12.style.display = 'none';
  modal13.style.display = 'none';
  modalContact.style.display = 'none';
  modalSupplier.style.display = 'none';
}

function outsideClick(e) {
  if (e.target == modal1) {
    modal1.style.display = 'none';
  } else if (e.target == modal2) {
    modal2.style.display = 'none';
  } else if (e.target == modal3) {
    modal3.style.display = 'none';
  } else if (e.target == modal4) {
    modal4.style.display = 'none';
  } else if (e.target == modal5) {
    modal5.style.display = 'none';
  } else if (e.target == modal6) {
    modal6.style.display = 'none';
  } else if (e.target == modal7) {
    modal7.style.display = 'none';
  } else if (e.target == modal8) {
    modal8.style.display = 'none';
  } else if (e.target == modal9) {
    modal9.style.display = 'none';
  } else if (e.target == modal10) {
    modal10.style.display = 'none';
  } else if (e.target == modal11) {
    modal11.style.display = 'none';
  } else if (e.target == modal12) {
    modal12.style.display = 'none';
  } else if (e.target == modal13) {
    modal13.style.display = 'none';
  } else if (e.target == modalContact) {
    modalContact.style.display = 'none';
  } else if (e.target == modalSupplier) {
    modalSupplier.style.display = 'none';
  }
}

const modalBtn1 = document.querySelector('.strength1');
const modal1 = document.querySelector('.modal1');
modalBtn1.addEventListener('click', openModal1);
function openModal1() {
  modal1.style.display = 'block';
}

const modalBtn2 = document.querySelector('.strength2');
const modal2 = document.querySelector('.modal2');
modalBtn2.addEventListener('click', openModal2);
function openModal2() {
  modal2.style.display = 'block';
}

const modalBtn3 = document.querySelector('.strength3');
const modal3 = document.querySelector('.modal3');
modalBtn3.addEventListener('click', openModal3);
function openModal3() {
  modal3.style.display = 'block';
}

const modalBtn4 = document.querySelector('.strength4');
const modal4 = document.querySelector('.modal4');
modalBtn4.addEventListener('click', openModal4);
function openModal4() {
  modal4.style.display = 'block';
}

const modalBtn5 = document.querySelector('.strength5');
const modal5 = document.querySelector('.modal5');
modalBtn5.addEventListener('click', openModal5);
function openModal5() {
  modal5.style.display = 'block';
}

const modalBtn6 = document.querySelector('.strength6');
const modal6 = document.querySelector('.modal6');
modalBtn6.addEventListener('click', openModal6);
function openModal6() {
  modal6.style.display = 'block';
}

const modalBtn7 = document.querySelector('.strength7');
const modal7 = document.querySelector('.modal7');
modalBtn7.addEventListener('click', openModal7);
function openModal7() {
  modal7.style.display = 'block';
}

const modalBtn8 = document.querySelector('.strength8');
const modal8 = document.querySelector('.modal8');
modalBtn8.addEventListener('click', openModal8);
function openModal8() {
  modal8.style.display = 'block';
}

const modalBtn9 = document.querySelector('.strength9');
const modal9 = document.querySelector('.modal9');
modalBtn9.addEventListener('click', openModal9);
function openModal9() {
  modal9.style.display = 'block';
}

const modalBtn10 = document.querySelector('.strength10');
const modal10 = document.querySelector('.modal10');
modalBtn10.addEventListener('click', openModal10);
function openModal10() {
  modal10.style.display = 'block';
}

const modalBtn11 = document.querySelector('.strength11');
const modal11 = document.querySelector('.modal11');
modalBtn11.addEventListener('click', openModal11);
function openModal11() {
  modal11.style.display = 'block';
}

const modalBtn12 = document.querySelector('.strength12');
const modal12 = document.querySelector('.modal12');
modalBtn12.addEventListener('click', openModal12);
function openModal12() {
  modal12.style.display = 'block';
}

const modalBtn13 = document.querySelector('.strength13');
const modal13 = document.querySelector('.modal13');
modalBtn13.addEventListener('click', openModal13);
function openModal13() {
  modal13.style.display = 'block';
}

const modalBtnContact = document.querySelectorAll('.navbar-links li')[2];
const modalContact = document.querySelector('.modalContact');
modalBtnContact.addEventListener('click', openModalContact);
function openModalContact() {
  modalContact.style.display = 'block';
}

const modalBtnSupplier = document.querySelector('.footer button');
const modalSupplier = document.querySelector('.modalSupplier');
modalBtnSupplier.addEventListener('click', openModalSupplier);
function openModalSupplier() {
  modalSupplier.style.display = 'block';
}